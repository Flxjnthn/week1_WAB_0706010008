package Model;
import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable{
    private int id;
    private String fullname, address, image_path, created;
    private int age;

    public User() {
        this.id = 0;
        this.fullname = "";
        this.address = "";
        this.image_path = "";
        this.created = "";
        this.age = 0;
    }
    public User(String fullname, String address, int age) {
        this.id = 0;
        this.fullname = fullname;
        this.address = address;
        this.image_path = "";
        this.created = "";
        this.age = age;
    }

    public User(int id, String fullname, String address, String image_path, String created, int age) {
        this.id = id;
        this.fullname = fullname;
        this.address = address;
        this.image_path = image_path;
        this.created = created;
        this.age = age;
    }

    protected User(Parcel in) {
        id = in.readInt();
        fullname = in.readString();
        address = in.readString();
        image_path = in.readString();
        created = in.readString();
        age = in.readInt();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImage_path() {
        return image_path;
    }

    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(fullname);
        dest.writeString(address);
        dest.writeString(image_path);
        dest.writeString(created);
        dest.writeInt(age);
    }
}

