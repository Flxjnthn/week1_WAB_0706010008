package com.example.week1_mad_0706012010008;

public interface OnCardListener {
    void onCardClick(int position);
}
